import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import subprocess
import sys
import os
import configparser
import platform
import threading
import queue
import time
from datetime import datetime

class ToursysGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Toursys 管理界面")
        self.root.geometry("600x500")
        
        # 配置文件路径
        self.config_file = "toursys_config.ini"
        
        # 应用状态
        self.process = None
        self.output_queue = queue.Queue()
        self.reading_output = False
        
        # 创建界面
        self.create_widgets()
        
        # 加载配置
        self.load_config()
        
        # 系统兼容性适配
        self.adapt_to_system()
        
        # 开始检查输出队列
        self.check_output_queue()
        
    def adapt_to_system(self):
        """根据不同的操作系统进行适配"""
        system = platform.system()
        if system == "Windows":
            # Windows特定设置
            try:
                self.root.iconbitmap(default="favicon.ico")  # 如果有图标文件的话
            except:
                pass  # 忽略图标加载错误
        # macOS和Linux通常不需要特殊处理
        
    def create_widgets(self):
        # 创建选项卡
        tab_control = ttk.Notebook(self.root)
        
        # 启动选项卡
        self.start_tab = ttk.Frame(tab_control)
        tab_control.add(self.start_tab, text="启动控制")
        
        # 配置选项卡
        self.config_tab = ttk.Frame(tab_control)
        tab_control.add(self.config_tab, text="配置管理")
        
        # 数据库选项卡
        self.db_tab = ttk.Frame(tab_control)
        tab_control.add(self.db_tab, text="数据库")
        
        # 图片处理选项卡
        self.image_tab = ttk.Frame(tab_control)
        tab_control.add(self.image_tab, text="图片处理")
        
        tab_control.pack(expand=1, fill="both")
        
        # 启动选项卡内容
        self.create_start_tab()
        
        # 配置选项卡内容
        self.create_config_tab()
        
        # 数据库选项卡内容
        self.create_db_tab()
        
        # 图片处理选项卡内容
        self.create_image_tab()
        
    def create_start_tab(self):
        # 端口配置
        port_frame = ttk.LabelFrame(self.start_tab, text="端口配置")
        port_frame.pack(padx=10, pady=10, fill="x")
        
        ttk.Label(port_frame, text="端口号:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.port_var = tk.StringVar(value="5000")
        self.port_entry = ttk.Entry(port_frame, textvariable=self.port_var, width=10)
        self.port_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        # 调试模式
        debug_frame = ttk.LabelFrame(self.start_tab, text="调试模式")
        debug_frame.pack(padx=10, pady=10, fill="x")
        
        self.debug_var = tk.BooleanVar()
        self.debug_check = ttk.Checkbutton(debug_frame, text="启用调试模式", variable=self.debug_var)
        self.debug_check.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        
        # 控制按钮
        control_frame = ttk.Frame(self.start_tab)
        control_frame.pack(padx=10, pady=20, fill="x")
        
        self.start_button = ttk.Button(control_frame, text="启动应用", command=self.start_app)
        self.start_button.pack(side="left", padx=5)
        
        self.stop_button = ttk.Button(control_frame, text="停止应用", command=self.stop_app, state="disabled")
        self.stop_button.pack(side="left", padx=5)
        
        # 状态显示
        status_frame = ttk.LabelFrame(self.start_tab, text="应用状态")
        status_frame.pack(padx=10, pady=10, fill="both", expand=True)
        
        self.status_text = tk.Text(status_frame, height=10, state="disabled")
        scrollbar = ttk.Scrollbar(status_frame, orient="vertical", command=self.status_text.yview)
        self.status_text.configure(yscrollcommand=scrollbar.set)
        
        self.status_text.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
    def create_config_tab(self):
        # 配置管理
        config_frame = ttk.LabelFrame(self.config_tab, text="配置管理")
        config_frame.pack(padx=10, pady=10, fill="both", expand=True)
        
        ttk.Button(config_frame, text="保存配置", command=self.save_config).pack(pady=10)
        ttk.Button(config_frame, text="加载默认配置", command=self.load_default_config).pack(pady=5)
        
    def create_db_tab(self):
        # 数据库管理
        db_frame = ttk.LabelFrame(self.db_tab, text="数据库操作")
        db_frame.pack(padx=10, pady=10, fill="both", expand=True)
        
        ttk.Button(db_frame, text="初始化数据库", command=self.init_db).pack(pady=10)
        ttk.Button(db_frame, text="备份数据库", command=self.backup_db).pack(pady=5)
        ttk.Button(db_frame, text="恢复数据库", command=self.restore_db).pack(pady=5)
        
    def create_image_tab(self):
        # 图片处理
        image_frame = ttk.LabelFrame(self.image_tab, text="图片处理")
        image_frame.pack(padx=10, pady=10, fill="both", expand=True)
        
        ttk.Button(image_frame, text="优化图片目录", command=self.optimize_images).pack(pady=10)
        ttk.Button(image_frame, text="清理未使用的图片", command=self.clean_images).pack(pady=5)
        
    def start_app(self):
        try:
            # 获取配置
            port = self.port_var.get()
            debug = self.debug_var.get()
            
            # 验证端口是否为有效数字
            try:
                port = int(port)
                if port < 1 or port > 65535:
                    raise ValueError("端口号必须在 1-65535 之间")
            except ValueError as e:
                messagebox.showerror("错误", f"无效的端口号: {str(e)}")
                return
            
            # 构建命令
            cmd = [sys.executable, "app.py"]
            
            # 添加环境变量
            env = os.environ.copy()
            env["PORT"] = str(port)
            env["DEBUG"] = "true" if debug else "false"
            
            # 启动进程（使用Popen的通用方式，避免平台特定问题）
            if platform.system() == "Windows":
                self.process = subprocess.Popen(
                    cmd,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                    universal_newlines=True,
                    creationflags=subprocess.CREATE_NO_WINDOW  # 在Windows上不创建控制台窗口
                )
            else:
                self.process = subprocess.Popen(
                    cmd,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                    universal_newlines=True
                )
            
            # 更新界面状态
            self.start_button.config(state="disabled")
            self.stop_button.config(state="normal")
            self.update_status(f"正在启动应用，端口: {port}，调试模式: {debug}\n")
            
            # 开始在线程中读取输出
            self.reading_output = True
            stdout_thread = threading.Thread(target=self.read_stdout, daemon=True)
            stderr_thread = threading.Thread(target=self.read_stderr, daemon=True)
            stdout_thread.start()
            stderr_thread.start()
            
        except Exception as e:
            messagebox.showerror("错误", f"启动应用时出错: {str(e)}")
            
    def read_stdout(self):
        """在独立线程中读取标准输出"""
        while self.process and self.process.poll() is None and self.reading_output:
            try:
                line = self.process.stdout.readline()
                if line:
                    self.output_queue.put(('stdout', line))
                else:
                    time.sleep(0.1)  # 避免过度占用CPU
            except Exception as e:
                self.output_queue.put(('error', f"读取输出时出错: {str(e)}"))
                break
                
    def read_stderr(self):
        """在独立线程中读取错误输出"""
        while self.process and self.process.poll() is None and self.reading_output:
            try:
                line = self.process.stderr.readline()
                if line:
                    self.output_queue.put(('stderr', line))
                else:
                    time.sleep(0.1)  # 避免过度占用CPU
            except Exception as e:
                self.output_queue.put(('error', f"读取错误输出时出错: {str(e)}"))
                break
    
    def check_output_queue(self):
        """定期检查输出队列并更新GUI（在主线程中运行）"""
        try:
            while True:
                # 非阻塞获取队列中的消息
                msg_type, message = self.output_queue.get_nowait()
                if msg_type == 'stdout':
                    self.update_status(f"[app-info]{message}")
                elif msg_type == 'stderr':
                    self.update_status(f"[flask-info] {message}")
                elif msg_type == 'error':
                    self.update_status(f"[sys-err] {message}")
        except queue.Empty:
            pass  # 队列为空是正常情况
        finally:
            # 继续定期检查队列
            self.root.after(100, self.check_output_queue)
            
    def stop_app(self):
        if self.process and self.process.poll() is None:
            try:
                # 停止读取输出
                self.reading_output = False
                
                # 尝试优雅地终止进程
                self.process.terminate()
                
                # 等待进程结束，最多等待5秒
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    # 如果进程没有响应，强制终止
                    self.process.kill()
                    self.process.wait()
                    
                self.update_status("应用已停止\n")
            except Exception as e:
                self.update_status(f"[错误] 停止应用时出错: {str(e)}\n")
            finally:
                self.process = None
                
                # 更新界面状态
                self.start_button.config(state="normal")
                self.stop_button.config(state="disabled")
        elif self.process:
            # 进程已经结束，但还没有清理
            self.process = None
            self.start_button.config(state="normal")
            self.stop_button.config(state="disabled")
            self.update_status("应用已停止\n")
            
    def update_status(self, message):
        """更新状态文本框（线程安全）"""
        # 添加时间戳
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {message}"
        
        # 确保在GUI线程中执行更新
        if self.root:
            self.root.after(0, self._update_status_text, formatted_message)
    
    def _update_status_text(self, message):
        """实际更新状态文本框（在主线程中调用）"""
        self.status_text.config(state="normal")
        self.status_text.insert(tk.END, message)
        self.status_text.see(tk.END)
        self.status_text.config(state="disabled")
        
    def save_config(self):
        config = configparser.ConfigParser()
        config["SERVER"] = {
            "port": self.port_var.get(),
            "debug": str(self.debug_var.get())
        }
        
        try:
            with open(self.config_file, "w") as f:
                config.write(f)
            messagebox.showinfo("成功", "配置已保存")
        except Exception as e:
            messagebox.showerror("错误", f"保存配置时出错: {str(e)}")
            
    def load_config(self):
        config = configparser.ConfigParser()
        if config.read(self.config_file):
            if "SERVER" in config:
                server_config = config["SERVER"]
                self.port_var.set(server_config.get("port", "5000"))
                self.debug_var.set(server_config.getboolean("debug", False))
                
    def load_default_config(self):
        self.port_var.set("5000")
        self.debug_var.set(False)
        messagebox.showinfo("信息", "已加载默认配置")
        
    def init_db(self):
        try:
            self.update_status("正在初始化数据库...\n")
            
            # 在后台线程中执行数据库初始化，避免阻塞GUI
            threading.Thread(target=self._init_db_background, daemon=True).start()
        except Exception as e:
            messagebox.showerror("错误", f"启动数据库初始化任务时出错: {str(e)}")
            self.update_status(f"启动数据库初始化任务时出错: {str(e)}\n")
            
    def _init_db_background(self):
        try:
            result = subprocess.run(
                [sys.executable, "init_db.py"],
                capture_output=True,
                text=True,
                cwd=os.getcwd()
            )
            
            if result.returncode == 0:
                def update_success():
                    messagebox.showinfo("成功", "数据库初始化成功")
                    self.update_status("数据库初始化成功\n")
                    if result.stdout:
                        self.update_status(f"输出:\n{result.stdout}\n")
                self.root.after(0, update_success)
            else:
                def update_error():
                    messagebox.showerror("错误", f"数据库初始化失败: {result.stderr}")
                    self.update_status(f"数据库初始化失败: {result.stderr}\n")
                    if result.stdout:
                        self.update_status(f"输出:\n{result.stdout}\n")
                self.root.after(0, update_error)
        except Exception as e:
            error_msg = str(e)  # 捕获异常信息到局部变量
            def update_exception():
                messagebox.showerror("错误", f"初始化数据库时出错: {error_msg}")
                self.update_status(f"初始化数据库时出错: {error_msg}\n")
            self.root.after(0, update_exception)
            
    def backup_db(self):
        try:
            self.update_status("正在备份数据库...\n")
            
            # 在后台线程中执行数据库备份，避免阻塞GUI
            threading.Thread(target=self._backup_db_background, daemon=True).start()
        except Exception as e:
            messagebox.showerror("错误", f"启动数据库备份任务时出错: {str(e)}")
            self.update_status(f"启动数据库备份任务时出错: {str(e)}\n")
            
    def _backup_db_background(self):
        try:
            # 实现数据库备份逻辑
            import shutil
            
            # 确定数据库文件路径
            db_path = os.path.join("instance", "toursys.db")
            if not os.path.exists(db_path):
                def update_error():
                    messagebox.showerror("错误", "数据库文件不存在")
                    self.update_status("错误: 数据库文件不存在\n")
                self.root.after(0, update_error)
                return
                
            # 创建备份文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"toursys_backup_{timestamp}.db"
            
            # 复制数据库文件
            shutil.copy2(db_path, backup_path)
            def update_success():
                messagebox.showinfo("成功", f"数据库已备份到 {backup_path}")
                self.update_status(f"数据库已备份到 {backup_path}\n")
            self.root.after(0, update_success)
        except Exception as e:
            error_msg = str(e)  # 捕获异常信息到局部变量
            def update_exception():
                messagebox.showerror("错误", f"备份数据库时出错: {error_msg}")
                self.update_status(f"备份数据库时出错: {error_msg}\n")
            self.root.after(0, update_exception)
            
    def restore_db(self):
        try:
            # 选择备份文件
            backup_file = filedialog.askopenfilename(
                title="选择数据库备份文件",
                filetypes=[("Database files", "*.db"), ("All files", "*.*")]
            )
            
            if not backup_file:
                self.update_status("数据库恢复已取消\n")
                return
                
            self.update_status(f"正在从 {os.path.basename(backup_file)} 恢复数据库...\n")
            
            # 在后台线程中执行数据库恢复，避免阻塞GUI
            threading.Thread(target=self._restore_db_background, args=(backup_file,), daemon=True).start()
        except Exception as e:
            messagebox.showerror("错误", f"启动数据库恢复任务时出错: {str(e)}")
            self.update_status(f"启动数据库恢复任务时出错: {str(e)}\n")
            
    def _restore_db_background(self, backup_file):
        try:
            # 确定数据库文件路径
            db_path = os.path.join("instance", "toursys.db")
            
            # 确保instance目录存在
            os.makedirs("instance", exist_ok=True)
            
            # 备份当前数据库（如果存在）
            if os.path.exists(db_path):
                import shutil
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_path = f"toursys_backup_{timestamp}_before_restore.db"
                shutil.copy2(db_path, backup_path)
                self.root.after(0, lambda: self.update_status(f"当前数据库已备份到 {backup_path}\n"))
            
            # 复制备份文件
            import shutil
            shutil.copy2(backup_file, db_path)
            def update_success():
                messagebox.showinfo("成功", "数据库恢复完成")
                self.update_status("数据库恢复完成\n")
            self.root.after(0, update_success)
        except Exception as e:
            error_msg = str(e)  # 捕获异常信息到局部变量
            def update_exception():
                messagebox.showerror("错误", f"恢复数据库时出错: {error_msg}")
                self.update_status(f"恢复数据库时出错: {error_msg}\n")
            self.root.after(0, update_exception)
            
    def optimize_images(self):
        try:
            self.update_status("正在优化图片...\n")
            
            # 在后台线程中执行图片优化，避免阻塞GUI
            threading.Thread(target=self._optimize_images_background, daemon=True).start()
        except Exception as e:
            messagebox.showerror("错误", f"启动图片优化任务时出错: {str(e)}")
            self.update_status(f"启动图片优化任务时出错: {str(e)}\n")
            
    def _optimize_images_background(self):
        try:
            # 实现图片优化逻辑
            try:
                from PIL import Image
            except ImportError:
                def update_error():
                    messagebox.showerror("错误", "请先安装PIL库: pip install Pillow")
                    self.update_status("错误: 需要PIL库，请安装Pillow\n")
                self.root.after(0, update_error)
                return
                
            import glob
            
            # 定义图片目录
            image_dirs = ["static/images", "static/uploads"]
            processed_count = 0
            error_count = 0
            
            # 遍历图片目录
            for image_dir in image_dirs:
                if not os.path.exists(image_dir):
                    self.root.after(0, lambda d=image_dir: self.update_status(f"跳过不存在的目录: {d}\n"))
                    continue
                    
                self.root.after(0, lambda d=image_dir: self.update_status(f"正在处理目录: {d}\n"))
                
                # 查找图片文件
                for ext in ["*.jpg", "*.jpeg", "*.png", "*.gif"]:
                    pattern = os.path.join(image_dir, ext)
                    for filepath in glob.glob(pattern):
                        try:
                            # 打开并优化图片
                            with Image.open(filepath) as img:
                                # 转换为RGB模式（如果需要）
                                if img.mode in ("RGBA", "P") and filepath.lower().endswith((".jpg", ".jpeg")):
                                    img = img.convert("RGB")
                                    
                                # 保存优化后的图片
                                img.save(filepath, optimize=True, quality=85)
                                processed_count += 1
                        except Exception as e:
                            # 跳过无法处理的文件
                            error_count += 1
                            error_msg = str(e)  # 捕获异常信息到局部变量
                            self.root.after(0, lambda f=filepath, msg=error_msg: self.update_status(f"警告: 无法处理 {f}: {msg}\n"))
                            continue
                            
            def update_result():
                messagebox.showinfo("成功", f"已优化 {processed_count} 个图片文件，{error_count} 个文件处理失败")
                self.update_status(f"图片优化完成: {processed_count} 个成功，{error_count} 个失败\n")
            self.root.after(0, update_result)
        except Exception as e:
            error_msg = str(e)  # 捕获异常信息到局部变量
            def update_exception():
                messagebox.showerror("错误", f"优化图片时出错: {error_msg}")
                self.update_status(f"优化图片时出错: {error_msg}\n")
            self.root.after(0, update_exception)
            
    def clean_images(self):
        try:
            self.update_status("正在清理未使用的图片...\n")
            
            # 在后台线程中执行清理操作，避免阻塞GUI
            threading.Thread(target=self._clean_images_background, daemon=True).start()
        except Exception as e:
            messagebox.showerror("错误", f"启动清理图片任务时出错: {str(e)}")
            self.update_status(f"启动清理图片任务时出错: {str(e)}\n")
            
    def _clean_images_background(self):
        try:
            # 实现清理未使用图片的逻辑
            import glob
            
            # 获取所有图片文件
            image_dirs = ["static/images", "static/uploads"]
            all_images = set()
            
            for image_dir in image_dirs:
                if not os.path.exists(image_dir):
                    self.root.after(0, lambda: self.update_status(f"跳过不存在的目录: {image_dir}\n"))
                    continue
                    
                for ext in ["*.jpg", "*.jpeg", "*.png", "*.gif"]:
                    pattern = os.path.join(image_dir, ext)
                    for filepath in glob.glob(pattern):
                        all_images.add(os.path.basename(filepath))
                        
            self.root.after(0, lambda: self.update_status(f"找到 {len(all_images)} 个图片文件\n"))
                        
            # 从数据库中获取正在使用的图片
            # 使用独立的数据库连接避免与主应用冲突
            import sqlite3
            used_images = set()
            
            try:
                db_path = os.path.join("instance", "toursys.db")
                if os.path.exists(db_path):
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()
                    
                    # 获取用户头像
                    cursor.execute("SELECT avatar FROM user")
                    users = cursor.fetchall()
                    for (avatar,) in users:
                        if avatar and avatar != 'default.jpg':
                            used_images.add(avatar)
                            
                    # 获取景点图片
                    cursor.execute("SELECT image_url FROM attraction")
                    attractions = cursor.fetchall()
                    for (image_url,) in attractions:
                        if image_url:
                            # 提取文件名
                            filename = os.path.basename(image_url)
                            used_images.add(filename)
                            
                    conn.close()
            except Exception as e:
                error_msg = str(e)  # 捕获异常信息到局部变量
                self.root.after(0, lambda msg=error_msg: self.update_status(f"数据库查询出错: {msg}\n"))
                        
            self.root.after(0, lambda: self.update_status(f"数据库中正在使用 {len(used_images)} 个图片文件\n"))
                        
            # 计算未使用的图片
            unused_images = all_images - used_images
            deleted_count = 0
            
            self.root.after(0, lambda: self.update_status(f"发现 {len(unused_images)} 个未使用的图片文件\n"))
            
            # 删除未使用的图片
            for image_dir in image_dirs:
                if not os.path.exists(image_dir):
                    continue
                    
                for filename in unused_images:
                    filepath = os.path.join(image_dir, filename)
                    if os.path.exists(filepath):
                        try:
                            os.remove(filepath)
                            deleted_count += 1
                            self.root.after(0, lambda f=filename: self.update_status(f"已删除: {f}\n"))
                        except Exception as e:
                            error_msg = str(e)  # 捕获异常信息到局部变量
                            self.root.after(0, lambda f=filename, msg=error_msg: self.update_status(f"无法删除 {f}: {msg}\n"))
                            
            def update_result():
                self.update_status(f"图片清理完成: {deleted_count} 个文件已删除\n")
                messagebox.showinfo("成功", f"已清理 {deleted_count} 个未使用的图片文件")
            self.root.after(0, update_result)
        except Exception as e:
            error_msg = str(e)  # 捕获异常信息到局部变量
            def update_exception():
                self.update_status(f"清理图片时出错: {error_msg}\n")
                messagebox.showerror("错误", f"清理图片时出错: {error_msg}")
            self.root.after(0, update_exception)

if __name__ == "__main__":
    root = tk.Tk()
    app = ToursysGUI(root)
    root.mainloop()
