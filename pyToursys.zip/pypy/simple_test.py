import sys
import traceback

try:
    print("尝试导入Flask...")
    from flask import Flask
    print("Flask导入成功")
    
    print("尝试导入SQLAlchemy...")
    from flask_sqlalchemy import SQLAlchemy
    print("SQLAlchemy导入成功")
    
    print("创建Flask应用...")
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///toursys.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    print("初始化SQLAlchemy...")
    db = SQLAlchemy(app)
    print("SQLAlchemy初始化成功")
    
    print("测试完成")
    
except Exception as e:
    print(f"错误: {e}")
    traceback.print_exc()
    sys.exit(1)