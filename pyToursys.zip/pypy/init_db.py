from app import app, db
from models import User, Attraction, Comment
from werkzeug.security import generate_password_hash
import os

def init_db():
    """初始化数据库并添加示例数据"""
    with app.app_context():
        # 创建所有表
        db.create_all()
        
        # 检查是否已有用户
        if User.query.first() is None:
            # 添加管理员用户
            admin = User(
                username='admin',
                email='admin@travel-site.com',
                is_admin=True
            )
            admin.set_password('admin123')
            db.session.add(admin)
            
            # 添加普通用户
            user = User(
                username='user1',
                email='user1@example.com'
            )
            user.set_password('password123')
            db.session.add(user)
            
            db.session.commit()
            
            print("已创建管理员账户 (用户名: admin, 密码: admin123)")
            print("已创建普通用户 (用户名: user1, 密码: password123)")
        
        # 检查是否已有景点
        if Attraction.query.first() is None:
            # 添加示例景点
            attractions = [
                {
                    'name': '长城',
                    'description': '长城是中国古代的军事防御工程，是世界文化遗产。',
                    'location': '北京',
                    'image_url': 'images/great_wall.jpg',
                    'category': '历史遗迹',
                    'price': 45.00
                },
                {
                    'name': '故宫',
                    'description': '故宫是中国明清两代的皇家宫殿，位于北京中轴线的中心。',
                    'location': '北京',
                    'image_url': 'images/forbidden_city.jpg',
                    'category': '历史遗迹',
                    'price': 60.00
                },
                {
                    'name': '西湖',
                    'description': '西湖位于杭州市，是中国著名的风景名胜区。',
                    'location': '杭州',
                    'image_url': 'images/west_lake.jpg',
                    'category': '自然风光',
                    'price': 0.00
                },
                {
                    'name': '黄山',
                    'description': '黄山位于安徽省，以奇松、怪石、云海、温泉四绝著称。',
                    'location': '黄山',
                    'image_url': 'images/huangshan.jpg',
                    'category': '自然风光',
                    'price': 230.00
                }
            ]
            
            for attr_data in attractions:
                attraction = Attraction(**attr_data)
                db.session.add(attraction)
            
            db.session.commit()
            print("已添加示例景点数据")
        
        print("数据库初始化完成")

if __name__ == '__main__':
    init_db()