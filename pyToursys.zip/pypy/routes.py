from flask import render_template, request, redirect, url_for, flash, jsonify, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db, login_manager
from models import User, Attraction, Comment
from forms import LoginForm, RegistrationForm, CommentForm, ProfileForm, PasswordForm, AttractionForm
from werkzeug.utils import secure_filename
import os
import uuid
from datetime import datetime
from sqlalchemy import or_

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# 首页
@app.route('/')
def index():
    # 获取评分最高的6个景点
    attractions = Attraction.query.order_by(Attraction.rating.desc()).limit(6).all()
    return render_template('index.html', attractions=attractions)

# 景点列表页
@app.route('/attractions_list')
def attractions_list():
    # 获取所有景点，按评分排序
    attractions = Attraction.query.order_by(Attraction.rating.desc()).all()
    return render_template('attractions_list.html', attractions=attractions)

# 景点详情页
@app.route('/attractions/<int:id>')
def attraction_detail(id):
    # 获取景点详情
    attraction = Attraction.query.get_or_404(id)
    
    # 获取评论，按创建时间倒序排列
    comments = Comment.query.filter_by(attraction_id=id).join(User).order_by(Comment.created_at.desc()).all()
    
    # 评论表单
    form = CommentForm()
    
    return render_template('attraction_detail.html', attraction=attraction, comments=comments, form=form)

# 搜索功能
@app.route('/search')
def search():
    query = request.args.get('query', '').strip()
    results = []
    
    if query:
        # 在景点名称、位置、描述中搜索
        results = Attraction.query.filter(
            or_(
                Attraction.name.contains(query),
                Attraction.location.contains(query),
                Attraction.description.contains(query)
            )
        ).all()
    
    return render_template('search.html', query=query, results=results)

# 用户注册
@app.route('/register', methods=['GET', 'POST'])
def register():
    # 如果用户已登录，重定向到首页
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        # 检查用户名或邮箱是否已存在
        existing_user = User.query.filter(
            (User.username == form.username.data) | (User.email == form.email.data)
        ).first()
        
        if existing_user:
            flash('用户名或邮箱已存在！', 'error')
        else:
            # 创建新用户
            user = User(username=form.username.data, email=form.email.data)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash('注册成功！请登录您的账户。', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

# 用户登录
@app.route('/login', methods=['GET', 'POST'])
def login():
    # 如果用户已登录，重定向到首页
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        # 查找用户（通过用户名或邮箱）
        user = User.query.filter(
            (User.username == form.username.data) | (User.email == form.username.data)
        ).first()
        
        # 验证用户和密码
        if user and user.check_password(form.password.data):
            login_user(user)
            # 重定向到之前访问的页面或首页
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('用户名或密码错误！', 'error')
    
    return render_template('login.html', form=form)

# 用户登出
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# 添加评论
@app.route('/add_comment', methods=['POST'])
@login_required
def add_comment():
    # 直接从请求中获取所有数据，不依赖WTForms验证
    attraction_id = request.form.get('attraction_id') or request.args.get('attraction_id')
    content = request.form.get('content', '').strip()
    rating = request.form.get('rating')
    
    # 检查必需字段
    if not attraction_id:
        flash('评论提交失败：缺少景点ID', 'error')
        return redirect(url_for('attractions_list'))
    
    if not content:
        flash('评论提交失败：评论内容不能为空', 'error')
        return redirect(url_for('attraction_detail', id=attraction_id))
    
    if not rating:
        flash('评论提交失败：请选择评分', 'error')
        return redirect(url_for('attraction_detail', id=attraction_id))
    
    try:
        # 验证数据类型
        attraction_id_int = int(attraction_id)
        rating_int = int(rating)
        
        if rating_int < 1 or rating_int > 5:
            raise ValueError("评分必须在1-5之间")
        
        # 检查景点是否存在
        attraction = Attraction.query.get(attraction_id_int)
        if not attraction:
            flash('评论提交失败：景点不存在', 'error')
            return redirect(url_for('attractions_list'))
        
        # 创建评论
        comment = Comment(
            user_id=current_user.id,
            attraction_id=attraction_id_int,
            content=content,
            rating=rating_int
        )
        db.session.add(comment)
        
        # 更新景点评分
        comments = Comment.query.filter_by(attraction_id=attraction_id_int).all()
        if comments:
            avg_rating = sum(c.rating for c in comments) / len(comments)
            attraction.rating = round(avg_rating, 2)
        else:
            attraction.rating = 0
        
        db.session.commit()
        flash('评论提交成功！', 'success')
        
    except ValueError as e:
        db.session.rollback()
        flash(f'评论提交失败：数据格式错误 - {str(e)}', 'error')
    except Exception as e:
        db.session.rollback()
        flash(f'评论提交失败：{str(e)}', 'error')
    
    return redirect(url_for('attraction_detail', id=attraction_id))

# 用户个人中心
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    # 个人信息表单
    profile_form = ProfileForm(obj=current_user)
    # 密码修改表单
    password_form = PasswordForm()
    
    if request.method == 'POST':
        # 处理个人信息更新
        if 'update_profile' in request.form and profile_form.validate_on_submit():
            # 检查用户名或邮箱是否已被其他用户使用
            existing_user = User.query.filter(
                ((User.username == profile_form.username.data) | (User.email == profile_form.email.data)) &
                (User.id != current_user.id)
            ).first()
            
            if existing_user:
                flash('用户名或邮箱已被其他用户使用！', 'error')
            else:
                # 更新用户信息
                current_user.username = profile_form.username.data
                current_user.email = profile_form.email.data
                db.session.commit()
                flash('个人信息更新成功！', 'success')
        
        # 处理密码修改
        elif 'change_password' in request.form and password_form.validate_on_submit():
            # 验证当前密码
            if current_user.check_password(password_form.current_password.data):
                # 设置新密码
                current_user.set_password(password_form.new_password.data)
                db.session.commit()
                flash('密码修改成功！', 'success')
            else:
                flash('当前密码不正确！', 'error')
    
    return render_template('profile.html', profile_form=profile_form, password_form=password_form)

# 头像上传
@app.route('/upload_avatar', methods=['POST'])
@login_required
def upload_avatar():
    if 'avatar' not in request.files:
        flash('没有接收到上传的文件。', 'error')
        return redirect(url_for('profile'))
    
    file = request.files['avatar']
    if file.filename == '':
        flash('没有选择文件。', 'error')
        return redirect(url_for('profile'))
    
    if file:
        # 检查文件类型
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif'}
        file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        if file_ext not in allowed_extensions:
            flash('只允许上传 JPG, JPEG, PNG, GIF 格式的图片。', 'error')
            return redirect(url_for('profile'))
        
        # 生成唯一的文件名
        filename = f"avatar_{current_user.id}_{int(datetime.timestamp(datetime.utcnow()))}.{file_ext}"
        filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        
        # 保存文件
        file.save(filepath)
        
        # 删除旧头像文件（如果不是默认头像）
        if current_user.avatar != 'default.jpg':
            old_avatar_path = os.path.join(current_app.config['UPLOAD_FOLDER'], current_user.avatar)
            if os.path.exists(old_avatar_path):
                os.remove(old_avatar_path)
        
        # 更新数据库中的头像路径
        current_user.avatar = filename
        db.session.commit()
        flash('头像上传成功！', 'success')
    
    return redirect(url_for('profile'))

# 管理员面板
@app.route('/admin')
@login_required
def admin():
    # 检查是否为管理员
    if not current_user.is_admin:
        flash('您没有管理员权限。', 'error')
        return redirect(url_for('index'))
    
    # 获取统计信息
    user_count = User.query.count()
    attraction_count = Attraction.query.count()
    
    return render_template('admin/admin.html', user_count=user_count, attraction_count=attraction_count)

# 管理员登录（专门的管理员登录页面）
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    # 如果用户已登录且是管理员，重定向到管理员面板
    if current_user.is_authenticated and current_user.is_admin:
        return redirect(url_for('admin'))
    
    form = LoginForm()
    if form.validate_on_submit():
        # 查找用户（通过用户名或邮箱）
        user = User.query.filter(
            (User.username == form.username.data) | (User.email == form.username.data)
        ).first()
        
        # 验证用户、密码和管理员权限
        if user and user.check_password(form.password.data):
            if user.is_admin:
                login_user(user)
                return redirect(url_for('admin'))
            else:
                flash('您没有管理员权限。', 'error')
        else:
            flash('用户名或密码错误！', 'error')
    
    return render_template('admin/login.html', form=form)

# 管理员用户管理
@app.route('/admin/users')
@login_required
def admin_users():
    # 检查是否为管理员
    if not current_user.is_admin:
        flash('您没有管理员权限。', 'error')
        return redirect(url_for('index'))
    
    # 获取所有用户
    users = User.query.order_by(User.created_at.desc()).all()
    
    # 计算管理员数量
    admin_count = User.query.filter_by(is_admin=True).count()
    
    return render_template('admin/admin_users.html', users=users, admin_count=admin_count)

# 管理员删除用户
@app.route('/admin/delete_user/<int:user_id>')
@login_required
def admin_delete_user(user_id):
    # 检查是否为管理员
    if not current_user.is_admin:
        flash('您没有管理员权限。', 'error')
        return redirect(url_for('index'))
    
    # 检查是否是最后一个管理员账户
    admin_count = User.query.filter_by(is_admin=True).count()
    user = User.query.get_or_404(user_id)
    
    if user.is_admin and admin_count <= 1:
        flash('无法删除最后一个管理员账户！系统必须至少保留一个管理员账户。', 'error')
    else:
        db.session.delete(user)
        db.session.commit()
        flash('用户删除成功', 'success')
    
    return redirect(url_for('admin_users'))

# 管理员景点管理
@app.route('/admin/attractions', methods=['GET', 'POST'])
@login_required
def admin_attractions():
    # 检查是否为管理员
    if not current_user.is_admin:
        flash('您没有管理员权限。', 'error')
        return redirect(url_for('index'))
    
    # 表单处理
    form = AttractionForm()
    edit_attraction = None
    
    # 如果是编辑模式，获取要编辑的景点
    edit_id = request.args.get('edit', type=int)
    if edit_id:
        edit_attraction = Attraction.query.get_or_404(edit_id)
        if request.method == 'GET':
            form = AttractionForm(obj=edit_attraction)
    
    # 处理表单提交
    if form.validate_on_submit():
        if edit_attraction:
            # 更新现有景点
            edit_attraction.name = form.name.data
            edit_attraction.description = form.description.data
            edit_attraction.location = form.location.data
            edit_attraction.category = form.category.data
            edit_attraction.price = form.price.data
            
            # 处理图片上传
            if form.cover_image.data:
                # 删除旧图片（如果不是默认图片）
                if edit_attraction.image_url and edit_attraction.image_url != 'default.jpg':
                    old_image_path = os.path.join(current_app.static_folder, edit_attraction.image_url)
                    if os.path.exists(old_image_path):
                        os.remove(old_image_path)
                
                # 保存新图片
                filename = save_image(form.cover_image.data)
                edit_attraction.image_url = f"uploads/{filename}"
            
            flash('景区更新成功', 'success')
        else:
            # 添加新景点
            attraction = Attraction(
                name=form.name.data,
                description=form.description.data,
                location=form.location.data,
                category=form.category.data,
                price=form.price.data
            )
            
            # 处理图片上传
            if form.cover_image.data:
                filename = save_image(form.cover_image.data)
                attraction.image_url = f"uploads/{filename}"
            
            db.session.add(attraction)
            flash('新景区添加成功', 'success')
        
        db.session.commit()
        return redirect(url_for('admin_attractions'))
    
    # 获取所有景点
    attractions = Attraction.query.order_by(Attraction.created_at.desc()).all()
    
    return render_template('admin/admin_attractions.html', 
                          attractions=attractions, 
                          form=form, 
                          edit_attraction=edit_attraction)

# 删除景点
@app.route('/admin/delete_attraction/<int:attraction_id>')
@login_required
def admin_delete_attraction(attraction_id):
    # 检查是否为管理员
    if not current_user.is_admin:
        flash('您没有管理员权限。', 'error')
        return redirect(url_for('index'))
    
    attraction = Attraction.query.get_or_404(attraction_id)
    
    # 删除图片文件
    if attraction.image_url and attraction.image_url != 'default.jpg':
        image_path = os.path.join(current_app.static_folder, attraction.image_url)
        if os.path.exists(image_path):
            os.remove(image_path)
    
    # 删除景点（会级联删除相关评论）
    db.session.delete(attraction)
    db.session.commit()
    flash('景区删除成功', 'success')
    
    return redirect(url_for('admin_attractions'))

# 保存图片的辅助函数
def save_image(file):
    # 生成唯一文件名
    filename = f"attraction_{int(datetime.timestamp(datetime.utcnow()))}_{uuid.uuid4().hex[:8]}.{file.filename.rsplit('.', 1)[1].lower()}"
    filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    
    # 保存文件
    file.save(filepath)
    return filename

# 404错误处理
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

# 500错误处理
@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500