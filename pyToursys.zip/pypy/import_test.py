import sys
import traceback

try:
    print("尝试导入app模块...")
    from app import app, db
    print("app模块导入成功")
    
    print("尝试导入models模块...")
    from models import User, Attraction, Comment
    print("models模块导入成功")
    
    print("测试完成")
    
except Exception as e:
    print(f"错误: {e}")
    traceback.print_exc()
    sys.exit(1)