from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, TextAreaField, SelectField, DecimalField, IntegerField, SubmitField, HiddenField
from wtforms.validators import DataRequired, Email, Length, NumberRange, ValidationError
from models import User
import re

class LoginForm(FlaskForm):
    username = StringField('用户名或邮箱', validators=[DataRequired()])
    password = PasswordField('密码', validators=[DataRequired()])
    submit = SubmitField('登录')

class RegistrationForm(FlaskForm):
    username = StringField('用户名', validators=[DataRequired(), Length(min=3, max=20)])
    email = StringField('邮箱', validators=[DataRequired(), Email()])
    password = PasswordField('密码', validators=[DataRequired(), Length(min=6)])
    submit = SubmitField('注册')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('该用户名已被使用。')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('该邮箱已被注册。')

class CommentForm(FlaskForm):
    attraction_id = HiddenField('景点ID', validators=[DataRequired()])
    content = TextAreaField('评论内容', validators=[DataRequired(), Length(min=1, max=500)])
    rating = SelectField('评分', 
                        choices=[('5', '5星'), ('4', '4星'), ('3', '3星'), ('2', '2星'), ('1', '1星')], 
                        validators=[DataRequired()])
    submit = SubmitField('提交评论')
    
    def validate_attraction_id(self, field):
        # 验证 attraction_id 是否为有效整数
        try:
            int(field.data)
        except (ValueError, TypeError):
            raise ValidationError('无效的景点ID')

class ProfileForm(FlaskForm):
    username = StringField('用户名', validators=[DataRequired(), Length(min=3, max=20)])
    email = StringField('邮箱', validators=[DataRequired(), Email()])
    submit = SubmitField('更新信息')

class PasswordForm(FlaskForm):
    current_password = PasswordField('当前密码', validators=[DataRequired()])
    new_password = PasswordField('新密码', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('确认新密码', validators=[DataRequired()])
    submit = SubmitField('修改密码')
    
    def validate_confirm_password(self, confirm_password):
        if self.new_password.data != confirm_password.data:
            raise ValidationError('新密码和确认密码不匹配。')

class AttractionForm(FlaskForm):
    name = StringField('名称', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('描述', validators=[DataRequired()])
    location = StringField('位置', validators=[DataRequired(), Length(max=100)])
    category = StringField('类别', validators=[DataRequired(), Length(max=50)])
    price = DecimalField('价格', validators=[DataRequired(), NumberRange(min=0)], places=2)
    cover_image = FileField('封面图片', validators=[FileAllowed(['jpg', 'jpeg', 'png', 'gif'], '只允许上传图片文件！')])
    submit = SubmitField('保存')