from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
import os

# 创建Flask应用实例
app = Flask(__name__, instance_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'instance'), instance_relative_config=True)

# 配置
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'dev-secret-key-for-toursys'
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///toursys.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(app.instance_path, '..', 'static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# 初始化扩展
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = '请先登录以访问此页面。'
csrf = CSRFProtect(app)

# 确保上传目录存在
os.makedirs(os.path.join(app.instance_path, '..', 'static', 'uploads'), exist_ok=True)

if __name__ == '__main__':
    # 在应用创建后再导入路由，避免循环导入
    from routes import *
    
    try:
        # 从环境变量获取端口和调试模式配置
        port = int(os.environ.get('PORT', 5000))
        debug = os.environ.get('DEBUG', 'True').lower() == 'true'
        
        print(f"启动 Toursys 应用，端口: {port}，调试模式: {debug}")
        app.run(host='127.0.0.1', port=port, debug=debug)
    except Exception as e:
        print(f"启动应用时出错: {e}")
        import traceback
        traceback.print_exc()
