import requests
from bs4 import BeautifulSoup
import traceback

# 首先访问登录页面获取CSRF token
session = requests.Session()
base_url = 'http://127.0.0.1:5000'

try:
    # 获取登录页面
    print("获取登录页面...")
    login_page = session.get(f'{base_url}/login')
    print(f"登录页面状态码: {login_page.status_code}")
    
    # 尝试登录
    login_data = {
        'username': 'admin',
        'password': 'admin123'
    }

    print("尝试登录...")
    response = session.post(f'{base_url}/login', data=login_data)
    print(f"登录响应状态码: {response.status_code}")
    
    if response.status_code == 200 or response.status_code == 302:
        print("登录成功或重定向")
        
        # 访问某个景点详情页
        attraction_id = 1  # 假设景点ID为1
        print(f"访问景点详情页 (ID: {attraction_id})...")
        detail_page = session.get(f'{base_url}/attractions/{attraction_id}')
        print(f"景点详情页状态码: {detail_page.status_code}")
        
        if detail_page.status_code == 200:
            print(f"成功访问景点详情页 (ID: {attraction_id})")
            
            # 解析页面获取表单信息
            soup = BeautifulSoup(detail_page.text, 'html.parser')
            form = soup.find('form', {'id': 'comment-form'})
            
            if form:
                print("找到评论表单")
                # 检查表单中是否包含attraction_id字段
                attraction_id_field = form.find('input', {'name': 'attraction_id'})
                if attraction_id_field:
                    print(f"找到attraction_id字段，值为: {attraction_id_field.get('value')}")
                else:
                    print("未找到attraction_id字段!")
                    # 打印表单内容以便调试
                    print("表单HTML内容:")
                    print(form.prettify())
                    
                # 尝试提交评论
                comment_data = {
                    'attraction_id': attraction_id,
                    'content': '这是一个测试评论',
                    'rating': '5'
                }
                
                print("尝试提交评论...")
                comment_response = session.post(f'{base_url}/add_comment', data=comment_data)
                print(f"评论提交响应状态码: {comment_response.status_code}")
                
                if comment_response.status_code == 302:
                    print("评论提交后重定向，可能是成功了")
                elif comment_response.status_code == 200:
                    print("评论提交后返回200，检查页面内容")
                    if "评论提交成功" in comment_response.text:
                        print("评论提交成功!")
                    elif "评论提交失败" in comment_response.text:
                        print("评论提交失败!")
                        # 打印失败原因
                        soup = BeautifulSoup(comment_response.text, 'html.parser')
                        flashes = soup.find_all('div', class_='alert')
                        for flash in flashes:
                            print(f"错误信息: {flash.text.strip()}")
                    else:
                        print("无法确定评论提交结果")
                        # 打印部分响应内容
                        print("响应内容前500字符:")
                        print(comment_response.text[:500])
            else:
                print("未找到评论表单")
                # 打印页面内容以便调试
                print("页面HTML内容 (前1000字符):")
                print(detail_page.text[:1000])
        else:
            print(f"无法访问景点详情页，状态码: {detail_page.status_code}")
    else:
        print(f"登录失败，状态码: {response.status_code}")
        
except Exception as e:
    print(f"发生异常: {e}")
    traceback.print_exc()