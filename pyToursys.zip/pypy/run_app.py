from app import app
import os

if __name__ == '__main__':
    # 在应用创建后再导入路由，避免循环导入
    from routes import *
    
    try:
        # 从环境变量获取端口和调试模式配置
        port = int(os.environ.get('PORT', 5000))
        debug = os.environ.get('DEBUG', 'True').lower() == 'true'
        
        print(f"启动 Toursys 应用，端口: {port}，调试模式: {debug}")
        app.run(host='127.0.0.1', port=port, debug=debug)
    except Exception as e:
        print(f"启动应用时出错: {e}")
        import traceback
        traceback.print_exc()