import sys
import traceback
import os

# 确保在正确的目录中
os.chdir('/home/swordreforge/桌面/Toursys/main')

try:
    print("1. 尝试导入app模块...")
    from app import app, db
    print("   app模块导入成功")
    
    print("2. 尝试导入models模块...")
    from models import User, Attraction, Comment
    print("   models模块导入成功")
    
    print("3. 尝试导入forms模块...")
    from forms import LoginForm, RegistrationForm, CommentForm, ProfileForm, PasswordForm, AttractionForm
    print("   forms模块导入成功")
    
    print("4. 尝试导入routes模块...")
    import routes
    print("   routes模块导入成功")
    
    print("5. 尝试初始化数据库...")
    with app.app_context():
        db.create_all()
        print("   数据库初始化成功")
        
    print("\n所有模块导入和初始化成功!")
    print("可以运行 'python app.py' 启动应用")
    
except Exception as e:
    print(f"导入失败: {e}")
    traceback.print_exc()
    sys.exit(1)