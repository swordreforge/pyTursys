import sys
import traceback
from app import app, db

def init_db():
    """初始化数据库"""
    try:
        with app.app_context():
            print("创建数据库表...")
            # 创建所有表
            db.create_all()
            print("数据库表创建成功")
    except Exception as e:
        print(f"错误: {e}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    init_db()