from app import app, db
from models import User, Attraction, Comment
import os

# 确保在应用上下文中运行
with app.app_context():
    # 检查数据库连接
    try:
        # 尝试查询用户表
        user_count = User.query.count()
        print(f"数据库连接成功，用户表记录数: {user_count}")
        
        # 检查是否存在admin用户
        admin_user = User.query.filter_by(username='admin').first()
        if admin_user:
            print(f"找到admin用户: {admin_user.username}, ID: {admin_user.id}")
            print(f"是否为管理员: {admin_user.is_admin}")
        else:
            print("未找到admin用户")
            
        # 检查景点表
        attraction_count = Attraction.query.count()
        print(f"景点表记录数: {attraction_count}")
        
        # 检查评论表
        comment_count = Comment.query.count()
        print(f"评论表记录数: {comment_count}")
            
    except Exception as e:
        print(f"数据库查询出错: {e}")
        import traceback
        traceback.print_exc()